
<?php
 
   //require "../lib/phpmailer/autoload.php";
  
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;

  require "phpmailer/exception.php";
  require "phpmailer/phpmailer.php";
  require "phpmailer/smtp.php";
  $strtxt = "";
  $mail = new PHPMailer(true);                                  // Passing `true` enables exceptions
  try {
      $mail->SMTPDebug = 0;                                 // Enable verbose debug output // 0 = off  //1 = errors and messages  //2 = messages only
      $mail->isSMTP();                                      // Set mailer to use SMTP
      $mail->Host = 'mail.unilead.in';                       // Specify main and backup SMTP servers
      $mail->SMTPAuth = true;                               // Enable SMTP authentication
      $mail->Username = 'chaman@unilead.in';                 // SMTP username
      $mail->Password = 'sQG}FJWQMT&M';                           // SMTP password
      $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
      $mail->Port = 465;                                    // TCP port to connect to
	  //Recipients
      $mail->setFrom('chaman@unilead.in', 'eBrickkiln.in');
      $mail->addAddress('chaman@unilead.in', 'Chaman CEO');     // Add a recipient

      //Content
      $mail->isHTML(true);                                  // Set email format to HTML
      $mail->Subject = 'Contact Enquery eBrickkiln.in';
     
	  
	$strtxt =$strtxt . "<html>";
	$strtxt =$strtxt . "<head>";
	$strtxt =$strtxt ."</head>";
	$strtxt =$strtxt . "<body>";
  $strtxt =$strtxt . '<table width="95%" border="1" cellspacing="1" cellpadding="1" align="center">';
  $strtxt =$strtxt . "<tr>";
	$strtxt =$strtxt . "<td> <b>eBrickkiln online Contact Enquery Detail </b><br></td>";
  $strtxt =$strtxt . "</tr>";
  $strtxt =$strtxt . "<tr>";
  $strtxt =$strtxt . "<td><b>Name:</b> </td><td> " . $_POST["Name"] . "<br></td>";
  $strtxt =$strtxt . "</tr>";  
  $strtxt =$strtxt . "<tr>";
  $strtxt =$strtxt . "<td><b>Contact Number:</b> </td><td> " . $_POST["Mobile"] . "<br></td>";
  $strtxt =$strtxt . "</tr>";
  $strtxt =$strtxt . "<tr>";
  $strtxt =$strtxt . "<td><b>Email:</b> </td><td> " . $_POST["Email"] . "<br></td>";
  $strtxt =$strtxt . "</tr>";
  $strtxt =$strtxt . "<tr>";
  $strtxt =$strtxt . "<td><b>Message:</b> </td><td> " . $_POST["Message"] . "<br></td>";
  $strtxt =$strtxt . "</tr>";
  
	$strtxt =$strtxt . "</Table>";
	$strtxt =$strtxt . "</boty>";
	$strtxt =$strtxt . "</html>";
	  
	  
	  $mail->Body = $strtxt;
	  
 //print_r($_POST);
$error_msg = "All required fields must be filled out "; 
//$success_msg = "Success. Message has been sent";
if(empty($_POST['Name']) || empty($_POST["Mobile"]) || empty($_POST["Email"]) || empty($_POST["Message"])){
echo '<div style=" color: red; font-weight: normal; ">'.$error_msg.'</div></br>';

} else {
      $mail->send();
      echo '<script>window.location.href = "http://www.ebrickkiln.com/welcome-best-bhatta-software-company.html";</script>';

   //  echo '<div style=" color: green; font-weight: normal; ">'.$success_msg.'</div></br>';
   //   header("Location: http://ebillpro.in/welcomemessage.html");
}
     
  } 
  
  catch (Exception $e) {
      echo 'error. Message could not be sent. Details: ', $mail->ErrorInfo;
  }

  ?>